"""Original metric reconstructions. GIS plan outlines; photo-guided approximate details.
Run Blender background. No imported third-party meshes or photographic texture pixels.
"""
import bpy,bmesh,math,json,sys,shutil,hashlib
import numpy as np
from pathlib import Path
from mathutils import Vector
R=Path(__file__).resolve().parents[1]
ASSETS=json.loads((R/'Evidence/site-dimensions.json').read_text())['assets']
KEY=sys.argv[sys.argv.index('--')+1] if '--' in sys.argv else 'MarinaCity'
D=ASSETS[KEY];N=D['nativeName'];OUT=R/KEY
for d in ['Source','Renders','Textures','Validation','Import/'+N]:(OUT/d).mkdir(parents=True,exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene;scene.unit_settings.system='METRIC';scene.unit_settings.scale_length=1
scene['author']='X_Bean_X';scene['source']='Original procedural reconstruction from user references and project OSM footprints.'
# Structural, shadow, stainless, roof, stone, trim, cream, dark; four glass groups.
palette=[(185,178,160),(31,39,43),(152,170,177),(80,87,85),
         (218,209,186),(240,234,213),(202,193,165),(39,44,45),
         (65,91,106),(69,94,110),(61,87,103),(67,92,107),
         (84,105,119),(231,222,200),(34,38,40),(158,148,112)]
if KEY=='TrumpTower':
    palette[0]=(139,163,174);palette[2]=(177,193,199)
    for i in range(8,12):palette[i]=(116+(i-8)*3,150+(i-8)*3,166+(i-8)*3)
elif KEY=='WrigleyBuilding':
    palette[0]=(231,224,203)
    for i in range(8,12):palette[i]=(46+i,60+i,65+i)
S=1024;T=256
arr={k:np.zeros((S,S,4),np.float32) for k in ['BaseColor','MaskMap','Normal','ControlMask','Emissive']}
arr['Normal'][:]=[.5,.5,1,1]
for i,col in enumerate(palette):
    x=i%4*T;y=(3-i//4)*T
    arr['BaseColor'][y:y+T,x:x+T]=[*[c/255 for c in col],1]
    arr['MaskMap'][y:y+T,x:x+T]=[.55 if KEY=='TrumpTower' or i==2 else .08,1,1 if 8<=i<=11 else 0,.8 if 8<=i<=12 else .3]
    arr['Emissive'][y:y+T,x:x+T]=[1,1,1,1] if 8<=i<=11 else [0,0,0,1]
images={}
for suffix,imarr in arr.items():
    im=bpy.data.images.new(N+'_'+suffix,width=S,height=S,alpha=True)
    im.colorspace_settings.name='sRGB' if suffix=='BaseColor' else 'Non-Color'
    im.pixels.foreach_set(imarr.ravel());im.filepath_raw=str(OUT/'Textures'/(suffix+'.png'));im.file_format='PNG';im.save();images[suffix]=im
mat=bpy.data.materials.new(N+'_Atlas');mat.use_nodes=True
bs=mat.node_tree.nodes.get('Principled BSDF');tex=mat.node_tree.nodes.new('ShaderNodeTexImage');tex.image=images['BaseColor']
mat.node_tree.links.new(tex.outputs['Color'],bs.inputs['Base Color'])
bs.inputs['Metallic'].default_value=.35 if KEY=='TrumpTower' else .07
bs.inputs['Roughness'].default_value=.27 if KEY=='TrumpTower' else .6
class Mesh:
    def __init__(self,name):
        self.name=name;self.v=[];self.f=[];self.tiles=[];self.areas=[0.]*4;self.counts=[0]*4;self.windows=[]
    def face(self,pts,tile):
        n=len(self.v);self.v.extend(pts);self.f.append(tuple(range(n,n+len(pts))));self.tiles.append(tile)
    def window(self,pts):
        a,b,c=map(Vector,pts[:3]);area=(b-a).cross(c-a).length
        # Independent per-window sampling, with no local quota or traversal cycle.
        # Spatial identity keeps a window's lighting identical across all LODs.
        identity=KEY+'|RandomWindowsR2|'+repr(sorted(tuple(round(float(v),4) for v in p) for p in pts))
        g=hashlib.sha256(identity.encode()).digest()[0]%4
        self.windows.append(dict(identity=identity,group=g,area=area))
        self.areas[g]+=area;self.counts[g]+=1;self.face(pts,8+g)
    def box(self,c,s,tile):
        x,y,z=c;w,d,h=[v/2 for v in s]
        p=[(x+i*w,y+j*d,z+k*h) for i,j,k in [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
        for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:self.face([p[i] for i in ids],tile)
    def beam(self,a,b,w,d,tile):
        a,b=Vector(a),Vector(b);z=(b-a).normalized();x=z.cross(Vector((0,0,1)))
        if x.length<.01:x=z.cross(Vector((0,1,0)))
        x.normalize();y=z.cross(x).normalized()
        p=[tuple(c+x*i*w/2+y*j*d/2) for c in [a,b] for i,j in [(-1,-1),(1,-1),(1,1),(-1,1)]]
        for ids in [(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]:self.face([p[i] for i in ids],tile)
    def poly(self,p,z,h,tile):
        if p[0]==p[-1]:p=p[:-1]
        self.face([(x,y,z) for x,y in p][::-1],tile);self.face([(x,y,z+h) for x,y in p],tile)
        for a,b in zip(p,p[1:]+p[:1]):self.face([(*a,z),(*b,z),(*b,z+h),(*a,z+h)],tile)
    def ring(self,c,r,z,h,tile,n=32,r2=None):
        p=[(c[0]+r*math.cos(i*math.tau/n),c[1]+r*math.sin(i*math.tau/n)) for i in range(n)]
        if r2 is None:self.poly(p,z,h,tile)
        else:
            q=[(c[0]+r2*math.cos(i*math.tau/n),c[1]+r2*math.sin(i*math.tau/n)) for i in range(n)]
            for i in range(n):
                j=(i+1)%n;self.face([(*p[i],z),(*p[j],z),(*q[j],z+h),(*q[i],z+h)],tile)
            self.face([(*v,z+h) for v in q],tile)
    def finish(self):
        me=bpy.data.meshes.new(self.name);me.from_pydata(self.v,[],self.f);me.materials.append(mat);me.update();uv=me.uv_layers.new()
        for p,t in zip(me.polygons,self.tiles):
            for j,l in enumerate(p.loop_indices):uv.data[l].uv=((t%4+.15+(j in [1,2])*.7)/4,(3-t//4+.15+(j>=2)*.7)/4)
        bm=bmesh.new();bm.from_mesh(me);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=.000001);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(me);bm.free()
        o=bpy.data.objects.new(self.name,me);scene.collection.objects.link(o);o['author']='X_Bean_X'
        return o
def clean(p):
    p=[tuple(v) for v in p]
    if math.dist(p[0],p[-1])<.001:p=p[:-1]
    # CCW outlines make the outward wall normal predictable.
    if sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(p,p[1:]+p[:1]))<0:p.reverse()
    return p
def facade(m,p,z0,z1,floors,lod,style):
    p=clean(p);fh=(z1-z0)/floors
    # Closed interior mass; windows slightly outside.
    m.poly(p,z0,z1-z0,0 if style=='stone' else 1)
    for edge,(a,b) in enumerate(zip(p,p[1:]+p[:1])):
        a,b=Vector(a),Vector(b);v=b-a;length=v.length
        if length<.3:continue
        out=Vector((v.y,-v.x)).normalized()
        cols=max(1,round(length/(2.9 if style=='stone' else 2.5)))
        for f in range(floors):
            za=z0+f*fh
            for k in range(cols):
                gap=.23 if style=='stone' else .035
                aa=a+v*(k+gap)/cols+out*.04;bb=a+v*(k+1-gap)/cols+out*.04
                low=za+(1.05 if style=='stone' else .22);high=za+fh-(.65 if style=='stone' else .18)
                if high<=low:continue
                m.window([(*aa,low),(*bb,low),(*bb,high),(*aa,high)])
                if style=='stone' and lod==0:
                    m.beam((*aa,low-.12),(*bb,low-.12),.22,.16,5)
                    mid=(aa+bb)/2;m.beam((*mid,low),(*mid,high),.055,.055,6)
            if lod<2 or f%3==0:
                q=a+out*.11;t=b+out*.11
                m.beam((*q,za),(*t,za),.13 if style=='glass' else .32,.19 if style=='glass' else .27,2 if style=='glass' else 5)
        if style=='glass' and lod<2:
            for k in range(cols+1):
                q=a+v*k/cols+out*.1;m.beam((*q,z0),(*q,z1),.075,.075,2)
        if style=='stone':
            for z in [z0,z1-1,z1]:
                q=a+out*.25;t=b+out*.25;m.beam((*q,z),(*t,z),.55,.55,5)
def marina(m,lod):
    for t,part in enumerate(D['parts'][:2]):
        c=np.array(part['center'])-D['centerXZ'];radius=19.75
        # Joined circular arcs give each balcony a projecting semicircular nose.
        # Their outer radius is identical to R2, preserving the map envelope.
        segments=[16,10,6][lod]
        n=16*segments
        centerR=16.5
        def ring(r):
            peak=r+1.8
            lobeR=peak-centerR
            theta=math.pi/16
            valley=centerR*math.cos(theta)+math.sqrt(lobeR*lobeR-(centerR*math.sin(theta))**2)
            arc=math.atan2(valley*math.sin(theta),valley*math.cos(theta)-centerR)
            pts=[]
            for lobe in range(16):
                a=lobe*math.tau/16
                normal=np.array([math.cos(a),math.sin(a)])
                tangent=np.array([-math.sin(a),math.cos(a)])
                for phi in np.linspace(-arc,arc,segments,endpoint=False):
                    p=c+normal*(centerR+lobeR*math.cos(phi))+tangent*(lobeR*math.sin(phi))
                    pts.append(tuple(p))
            return pts
        r=radius-1.8
        m.ring(c,6.0,0,179.2224,0,n=32 if lod<2 else 16)
        m.ring(c,17.1,0,3,0,n=n)
        for f in range(19):
            z=3+f*2.74
            m.ring(c,18.3,z,.3,0,n=n)
            for i in range(16):
                a=i*math.tau/16;x,y=c+[16.8*math.cos(a),16.8*math.sin(a)]
                m.box((x,y,z+1.42),(.48,.48,2.55),0)
            if lod==0:
                # Spiral ramp is inside the garage, with open periphery.
                for i in range(32):
                    a=i*math.tau/32;b=(i+1)*math.tau/32
                    m.face([(c[0]+rr*math.cos(ang),c[1]+rr*math.sin(ang),z+.3+2.74*ang/math.tau) for rr,ang in [(7,a),(12,a),(12,b),(7,b)]],3)
        m.poly(ring(r),54.6,1.5,0)
        for f in range(40):
            z=56+f*(111.5/40)
            m.poly(ring(r),z,.26,0)
            for i in range(48):
                a=i*math.tau/48;b=(i+1)*math.tau/48
                aa=c+15.0*np.array([math.cos(a),math.sin(a)]);bb=c+15.0*np.array([math.cos(b),math.sin(b)])
                m.window([(*aa,z+.28),(*bb,z+.28),(*bb,z+2.55),(*aa,z+2.55)])
            # Recessed dark guards and narrow pale caps show the round slab noses.
            pts=ring(r-.025)
            for i in range(n):
                a=pts[i];b=pts[(i+1)%n]
                m.face([(*a,z+.48),(*b,z+.48),(*b,z+1.12),(*a,z+1.12)],1)
                m.face([(*a,z+1.12),(*b,z+1.12),(*b,z+1.18),(*a,z+1.18)],0)
            if lod<2:
                # Slim vertical dividers sit in the valleys between adjacent lobes.
                valleyPt=ring(r)[0]
                vr=math.dist(valleyPt,c)
                for i in range(16):
                    a=(i-.5)*math.tau/16;x,y=c+vr*np.array([math.cos(a),math.sin(a)])
                    m.box((x,y,z+1.39),(.20,.20,2.78),0)
        m.poly(ring(r),167.5,1.0,0)
        m.ring(c,8,168.5,3,0,n=32);m.ring(c,5.1,171.5,7.7224,0,n=24)
        for a in np.linspace(0,math.tau,12,endpoint=False):
            x,y=c+6*np.array([math.cos(a),math.sin(a)]);m.box((x,y,170),(.3,.3,2.8),0)
def trump(m,lod):
    top=0
    for part,z,floors in zip(D['parts'][:5],[60,120,200,345,357],[18,15,20,36,3]):
        facade(m,part['localXY'],top,z,floors,lod,'glass')
        # Silver horizontal mechanical bands emphasize three stepped setbacks.
        p=clean(part['localXY']);m.poly(p,max(top,z-1.25),1.25,2);top=z
    for part,z1,z2 in zip(D['parts'][5:],[357,380,400],[380,400,423.2]):
        p=clean(part['localXY']);m.poly(p,z1,z2-z1,2)
    # Recessed entry columns inside measured podium outline.
    p=clean(D['parts'][0]['localXY'])
    for a,b in zip(p,p[1:]+p[:1]):
        v=Vector(b)-Vector(a)
        if v.length>12:
            for t in np.linspace(.1,.9,max(2,round(v.length/6))):
                q=Vector(a)+v*t;m.box((*q,3),(.55,.55,6),2)
def clock(m,c,z,side):
    x,y=c;normal=Vector([(0,-1),(1,0),(0,1),(-1,0)][side]);right=Vector((-normal.y,normal.x))
    def pt(u,v,off=0):q=Vector((x,y))+normal*(8.55+off)+right*u;return (q.x,q.y,z+v)
    n=48
    m.face([pt(3.7*math.cos(a),3.7*math.sin(a),.02) for a in np.linspace(0,math.tau,n,endpoint=False)],5)
    for i in range(60):
        a=i*math.tau/60;r0=3.1 if i%5==0 else 3.35;r1=3.55
        m.beam(pt(r0*math.sin(a),r0*math.cos(a),.07),pt(r1*math.sin(a),r1*math.cos(a),.07),.11 if i%5==0 else .035,.06,14)
    m.beam(pt(0,0,.12),pt(-1.75,1.2,.12),.18,.12,14)
    m.beam(pt(0,0,.14),pt(1.3,2.8,.14),.12,.10,14)
def wrigley(m,lod):
    south,north,tower=D['parts']
    facade(m,south['localXY'],0,66,16,lod,'stone')
    facade(m,north['localXY'],0,66,16,lod,'stone')
    tc=np.array(tower['center'])-D['centerXZ'];cx,cy=tc
    tp=clean(tower['localXY'])
    facade(m,tp,66,103,9,lod,'stone')
    for side in range(4):clock(m,tc,98.2,side)
    # Open Renaissance belfry, receding tiers, copper-grey cap and finial.
    for z,w,h in [(103,18.2,1),(104,14.5,1),(112.5,14.6,1.2),(114,10.5,1),(120,10.5,.8)]:
        m.box((cx,cy,z+h/2),(w,w,h),5)
    for z,w,h in [(105,12.4,7.5),(115,8.5,5)]:
        m.box((cx,cy,z+h/2),(w-3,w-3,h),1)
        for a in [-1,0,1]:
            for side in range(4):
                x,y=(cx+a*w*.4,cy+(-1 if side==0 else 1)*w/2) if side<2 else (cx+(-1 if side==2 else 1)*w/2,cy+a*w*.4)
                m.box((x,y,z+h/2),(.58,.58,h),5)
    m.ring(tc,5.6,120.8,4.4,3,n=8,r2=1.4)
    m.ring(tc,.8,125.2,2.6,5,n=8,r2=.35)
    m.ring(tc,.18,127.8,1.74,2,n=8)
    # North wing ornamental roof pavilion, all inside its actual plan.
    nc=np.array(north['center'])-D['centerXZ'];nx,ny=nc
    m.box((nx+7,ny,69),(27,23,6),0)
    for z,w,d,h in [(72,28,24,.8),(73,19,16,6),(79,20,17,.8),(80,10,10,6)]:
        if h<1:m.box((nx+7,ny,z+h/2),(w,d,h),5)
        else:
            pp=[(nx+7-w/2,ny-d/2),(nx+7+w/2,ny-d/2),(nx+7+w/2,ny+d/2),(nx+7-w/2,ny+d/2)]
            facade(m,pp,z,z+h,1,lod,'stone')
            for x in [-w/2,w/2]:
                for y in [-d/2,d/2]:m.box((nx+7+x,ny+y,z+h/2),(.8,.8,h),5)
    m.ring((nx+7,ny),6,86,2.5,3,n=4,r2=.7)
    m.ring((nx+7,ny),.3,88.5,1.1,5,n=8)
    # Resolve the facing walls across the full bridge width, not global extrema.
    x=cx-9
    def crossings(part,xx):
        p=clean(part['localXY']);ys=[]
        for a,b in zip(p,p[1:]+p[:1]):
            if min(a[0],b[0])<=xx<=max(a[0],b[0]) and abs(b[0]-a[0])>1e-8:
                ys.append(a[1]+(xx-a[0])*(b[1]-a[1])/(b[0]-a[0]))
        assert len(ys)>=2,('Bridge outside wing',xx)
        return min(ys),max(ys)
    samples=sorted({x-3.5,x,x+3.5}|{v[0] for part in [south,north] for v in clean(part['localXY']) if x-3.5<v[0]<x+3.5})
    sb=min(crossings(south,xx)[1] for xx in samples)-.6
    nb=max(crossings(north,xx)[0] for xx in samples)+.6
    assert nb>sb
    assert all(crossings(south,xx)[0]<sb<crossings(south,xx)[1] and crossings(north,xx)[0]<nb<crossings(north,xx)[1] for xx in samples)
    for z in [11.5,44]:
        m.box((x,(sb+nb)/2,z+1.65),(7,nb-sb,3.3),0)
        for side in [-1,1]:
            for j in range(max(1,int((nb-sb)/2))):
                ya=sb+j*2+.3;yb=min(nb-.3,ya+1.4)
                if yb>ya:m.window([(x+side*3.55,ya,z+.7),(x+side*3.55,yb,z+.7),(x+side*3.55,yb,z+2.6),(x+side*3.55,ya,z+2.6)])
    if lod==0:
        (OUT/'Validation/walkways-r3.json').write_text(json.dumps(dict(x=x,width=7,southEnd=sb,northEnd=nb,length=nb-sb,levels=[11.5,44],wallOverlapMin=.6,fullWidthConnected=True,sampledX=samples),indent=2))
    if lod<2:
        for part in [south,north]:
            for a,b in zip(clean(part['localXY']),clean(part['localXY'])[1:]+clean(part['localXY'])[:1]):
                v=Vector(b)-Vector(a)
                if v.length<4:continue
                for t in np.linspace(.1,.9,max(2,int(v.length/4))):
                    q=Vector(a)+v*t;m.box((*q,67.1),(.6,.6,2),5)
builders={'MarinaCity':marina,'TrumpTower':trump,'WrigleyBuilding':wrigley}
objects=[];reports=[];planFitScale=None
for lod in range(3):
    mesh=Mesh(N+('WalkwaysR3' if KEY=='WrigleyBuilding' else 'RoundBalconiesR4' if KEY=='MarinaCity' else 'RandomR2')+(f'_LOD{lod}' if lod else ''));builders[KEY](mesh,lod)
    if planFitScale is None:
        planFitScale=min(1.0,*[(D['envelopeM'][axis]/2-.005)/max(abs(p[axis]) for p in mesh.v) for axis in (0,1)])
    # Keep decorative projections inside the map's measured site envelope.
    # Apply one horizontal scale to every LOD; retain the full metric height.
    mesh.v=[(x*planFitScale,y*planFitScale,max(0,z)) for x,y,z in mesh.v]
    o=mesh.finish();objects.append(o)
    bpy.context.view_layer.objects.active=o;o.select_set(True)
    mod=o.modifiers.new('Triangulated export','TRIANGULATE');bpy.ops.object.modifier_apply(modifier=mod.name)
    co=np.array([v.co[:] for v in o.data.vertices]);bm=bmesh.new();bm.from_mesh(o.data)
    assert all(max(abs(co[:,axis]))<=D['envelopeM'][axis]/2+.001 for axis in (0,1))
    assert abs(co[:,2].max()-D['height'])<.001
    if lod==0:
        (OUT/'Validation/plan-vertices.json').write_text(json.dumps(np.unique(np.round(co[:,:2],4),axis=0).tolist()))
    deg=sum(f.calc_area()<1e-9 for f in bm.faces);bm.free()
    assert deg==0,(KEY,lod,deg)
    fractions=[a/sum(mesh.areas) for a in mesh.areas]
    assert all(.2<=f<=.3 for f in fractions)
    signature=hashlib.sha256(json.dumps(mesh.windows,sort_keys=True).encode()).hexdigest()
    groups=[w['group'] for w in mesh.windows]
    adjacentSame=sum(a==b for a,b in zip(groups,groups[1:]))/max(1,len(groups)-1)
    reports.append(dict(lod=lod,triangles=len(o.data.polygons),vertices=len(o.data.vertices),boundsMin=co.min(0).tolist(),boundsMax=co.max(0).tolist(),degenerateFaces=deg,windowCount=sum(mesh.counts),groupCounts=mesh.counts,litFractions=fractions[:3],unlitGroupFraction=fractions[3],lightingRevision='RandomWindowsR2',windowAssignmentSHA256=signature,adjacentSameGroupFraction=adjacentSame))
    bpy.ops.object.select_all(action='DESELECT');o.hide_set(False);o.select_set(True)
    dest=OUT/'Import'/N
    bpy.ops.export_scene.fbx(filepath=str(dest/(o.name+'.fbx')),use_selection=True,object_types={'MESH'},axis_forward='-Z',axis_up='Y',bake_space_transform=True,apply_unit_scale=True,apply_scale_options='FBX_SCALE_NONE',mesh_smooth_type='FACE',use_tspace=True,bake_anim=False,add_leaf_bones=False,use_custom_props=True)
    for suffix in arr:shutil.copy2(OUT/'Textures'/(suffix+'.png'),dest/(o.name+'_'+suffix+'.png'))
    o.hide_render=lod!=0;o.hide_set(lod!=0);o.select_set(False)
assert len({r['windowAssignmentSHA256'] for r in reports})==1,'LOD lighting mismatch'
(OUT/'Validation/mesh-export.json').write_text(json.dumps(dict(asset=KEY,author='X_Bean_X',meshes=reports,stages=3,cycleSeconds=180,lightingRevision='RandomWindowsR2',planFitScale=planFitScale,mapEnvelopeM=D['envelopeM'],heightM=D['height'],geometricDetail='Original reconstruction; decorative details approximate.'),indent=2))
scene.world=bpy.data.worlds.new('Studio');scene.world.use_nodes=True
bg=scene.world.node_tree.nodes['Background'];bg.inputs[0].default_value=(.35,.43,.53,1);bg.inputs[1].default_value=.6
bpy.ops.object.light_add(type='SUN');sun=bpy.context.object;sun.data.energy=3;sun.rotation_euler=(.5,-.5,-.7);sun.data.angle=.12
h=D['height'];span=max(D['envelopeM']);target=Vector((0,0,h*.46))
bpy.ops.object.camera_add(location=(span*3,-span*4,h*.8));cam=bpy.context.object;scene.camera=cam
cam.data.type='ORTHO';cam.data.ortho_scale=max(h*1.18,span*1.55);cam.data.clip_end=5000
cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
scene.render.engine='CYCLES';scene.cycles.samples=20;scene.cycles.use_denoising=True
try:
    prefs=bpy.context.preferences.addons['cycles'].preferences;prefs.compute_device_type='OPTIX';prefs.get_devices()
    for dev in prefs.devices:dev.use=dev.type=='OPTIX'
    if any(dev.type=='OPTIX' for dev in prefs.devices):scene.cycles.device='GPU'
except Exception:pass
scene.render.resolution_x=1100;scene.render.resolution_y=1400;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.view_settings.view_transform='AgX'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'Source'/(N+'.blend')))
scene.render.filepath=str(OUT/'Renders/day.png');bpy.ops.render.render(write_still=True)
bg.inputs[1].default_value=.07;sun.data.energy=.12
emit=mat.node_tree.nodes.new('ShaderNodeTexImage');mat.node_tree.links.new(emit.outputs['Color'],bs.inputs['Emission Color']);bs.inputs['Emission Strength'].default_value=1.3
for stage in range(3):
    ar=np.zeros((S,S,4),np.float32);ar[:,:,3]=1;i=8+stage;x=i%4*T;y=(3-i//4)*T;ar[y:y+T,x:x+T]=[1,.69,.34,1]
    im=bpy.data.images.new('NightPattern'+str(stage+1),width=S,height=S,alpha=True);im.pixels.foreach_set(ar.ravel());emit.image=im
    scene.render.filepath=str(OUT/'Renders'/f'night-{stage+1}.png');bpy.ops.render.render(write_still=True)
print('BUILD_COMPLETE',KEY,json.dumps(reports))
